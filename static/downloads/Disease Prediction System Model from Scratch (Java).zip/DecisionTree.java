import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

public class DecisionTree {
    
    public static void main(String[] args) {
        
        // Read data from CSV File.
        // Label column must be at the last column.
        List<Object> csvData = Helpers.readData("train.csv");

        Data trainData = (Data) csvData.get(2);
        Data testData  = (Data) Helpers.readData("test.csv").get(2);

        // Get columnHeaders from training dataset to classify test data.
        @SuppressWarnings("unchecked")
        List<String> columnHeaders = (List<String>) csvData.get(3);



        // Build Decision Tree.
        @SuppressWarnings("unchecked")
        Hashtable<String, List<Object>> decisionTree = (Hashtable<String, List<Object>>) buildDecisionTree(trainData, columnHeaders);

        
        // Classify test data.
        // If there are only one test data then no need to loop.
        for (int i=0; i < testData.getLength(); i++) {
            Object prediction = classifyExample(testData.getOne(i), columnHeaders, decisionTree);

            System.out.println((String) prediction);
        }
    }


    /** Check purity of the data and returns boolean value.
        Returns true if there is only one unique target (label) value. (Pure Data)
        Returns false if there are more than one unique target (label) values. (Impure Data)
     */
    public static boolean checkPurity(Data data) {
        List<String> uniqueTargets = Helpers.getUniqueValues(data.getColumn(data.getShape().get(1) - 1));

        if (uniqueTargets.size() == 1) {
            return true;
        } else {
            return false;
        }
    }



    /** Classify the data and returns KeyValuePair<String, Integer>
        String: Class label (target value)
        Integer: Index of Class in Label column.
     */
    public static KeyValuePair<String, Integer> classifyData(Data data) {
        List<String> uniqueTargets = Helpers.getUniqueValues(data.getColumn(data.getShape().get(1) - 1));
        List<KeyValuePair<String, Integer>> frequencyPair = Helpers.getFrequency(uniqueTargets, data.getColumn(data.getShape().get(1) - 1));

        List<String> frKeys = new ArrayList<String>();
        List<Integer> frValues = new ArrayList<Integer>();

        for (KeyValuePair<String, Integer> k: frequencyPair) {
            frKeys.add(k.key);
            frValues.add(k.value);
        }

        Integer index = Helpers.getIndexOfMaxFrequency(frValues);
        String target = frKeys.get(index);

        return new KeyValuePair<String, Integer>(target, index);
    }



    /** Returns List of all Potential Splits from the data as List<List<String>>
     */
    public static List<List<String>> getPotentialSplits(Data data) {
        Integer columnShape = data.getShape().get(1);

        List<List<String>> potentialSplits = new ArrayList<List<String>>();

        for (int i=0; i < columnShape - 1; i++) {
            List<String> columnvalues = data.getColumn(i);
            List<String> uniqueValues = Helpers.getUniqueValues(columnvalues);

            potentialSplits.add(uniqueValues);
        }

        return potentialSplits;
    }



    /** Splits the data with respect to split value into two subsets of data as Data Below and Data Above.
        Returns List of Data containing Data Below and Data Above respectively.
     */
    public static List<Data> splitData(Data data, int splitColumn, String splitValue) {
        List<String> splitColumnValues = data.getColumn(splitColumn);

        Data dataBelow = new Data();
        Data dataAbove = new Data();

        List<DataValue> dataBelowRows = new ArrayList<DataValue>();
        List<DataValue> dataAboveRows = new ArrayList<DataValue>();

        for (int i=0; i < splitColumnValues.size(); i++) {
            if (splitColumnValues.get(i).equals(splitValue)) {
                dataBelowRows.add(data.rows.get(i));
            } else {
                dataAboveRows.add(data.rows.get(i));
            }
        }

        dataBelow = new Data(dataBelowRows);
        dataAbove = new Data(dataAboveRows);

        List<Data> tempData = new ArrayList<Data>();
        tempData.add(dataBelow);
        tempData.add(dataAbove);

        return tempData;
    }

    // This overload takes best split value as an input.
    public static List<Data> splitData(Data data, KeyValuePair<Integer, String> split) {
        return splitData(data, split.key, split.value);
    }



    /** Calculates shannon entropy of the data and returns a float value.
     */
    public static Float calculateEntropy(Data data) {
        List<String> uniqueTargets = Helpers.getUniqueValues(data.getColumn(data.getShape().get(1) - 1));
        List<KeyValuePair<String, Integer>> frequencyPair = Helpers.getFrequency(uniqueTargets, data.getColumn(data.getShape().get(1) - 1));

        List<String> frKeys = new ArrayList<String>();
        List<Integer> frValues = new ArrayList<Integer>();
        for (KeyValuePair<String, Integer> k: frequencyPair) {
            frKeys.add(k.key);
            frValues.add(k.value);
        }

        Integer sumOfFrequency = frValues.stream().mapToInt(Integer::intValue).sum();
        List<Float> probabilities = new ArrayList<Float>();
        for (Integer i: frValues) {
            probabilities.add(i.floatValue() / sumOfFrequency.floatValue());
        }

        List<Float> logValues = new ArrayList<Float>();
        for (Float f: probabilities) {
            logValues.add((float)(Math.log(f) / Math.log(2)));
        }

        List<Double> entropyValues = new ArrayList<Double>();
        for (int i=0; i < logValues.size(); i++) {
            entropyValues.add((double)(probabilities.get(i) * -(logValues.get(i))));
        }

        return (float)entropyValues.stream().mapToDouble(Double::doubleValue).sum();
    }



    /** Calculates overall entropy of the data and returns a float value.
     */
    public static Float calculateOverallEntropy(Data dataBelow, Data dataAbove) {
        Integer nDataPoints = dataBelow.getLength() + dataAbove.getLength();
        Float pDataBelow = dataBelow.getLength().floatValue() / nDataPoints.floatValue();
        Float pDataAbove = dataAbove.getLength().floatValue() / nDataPoints.floatValue();

        Float overallEntropy = (pDataBelow * calculateEntropy(dataBelow) + pDataAbove * calculateEntropy(dataAbove));
        return overallEntropy;
    }



    /** Determines best split value to split the data into two subsets and returns KeyValuePair<Integer, String>
        Integer: Column Index
        String: Split Value (categorical data)
     */
    public static KeyValuePair<Integer, String> determineBestSplit(Data data, List<List<String>> potentialSplits) {
        Float overallEntropy = (float) 999;
        Integer columnIndex = 0;
        String splitValue = "";

        for (List<String> k: potentialSplits) {
            for (String value: k) {
                List<Data> splitDataList = splitData(data, potentialSplits.indexOf(k), value);
                Data dataBelow = splitDataList.get(0);
                Data dataAbove = splitDataList.get(1);

                Float currentOverallEntropy = calculateOverallEntropy(dataBelow, dataAbove);
                if (currentOverallEntropy < overallEntropy) {
                    columnIndex = potentialSplits.indexOf(k);
                    splitValue = value;
                }
            }
        }

        return new KeyValuePair<Integer, String>(columnIndex, splitValue);
    }



    /** Function is a recursive function which returns an object of question or answer.
        Finally returns a Decision Tree made of Sub Trees.
     */
    public static Object buildDecisionTree(Data data, List<String> columnHeaders) {

        // Check purity of the data.
        // If data is pure then classify the data and return Yes answer (Label of class).
        if (checkPurity(data)) {
            KeyValuePair<String, Integer> classification = classifyData(data);
            return classification.key;

        } else {

            // Get the best split value to make split in the data.
            List<List<String>> potentialSplits = getPotentialSplits(data);
            KeyValuePair<Integer, String> bestSplit = determineBestSplit(data, potentialSplits);

            List<Data> splitDataList = splitData(data, bestSplit);
            Data dataBelow = splitDataList.get(0);
            Data dataAbove = splitDataList.get(1);

            // Check for null data.
            // If null data then classify the data and return Yes answer (Label of class).
            if (dataBelow.getLength() == 0 || dataAbove.getLength() == 0) {
                KeyValuePair<String, Integer> classification = classifyData(data);
                return classification.key;
            }

            // Make categorical question to classify the test data.
            String question = String.format("%s = %s", columnHeaders.get(bestSplit.key), bestSplit.value);

            // Initialize the sub tree.
            // String: Question
            // List<Object>: Answers
            Hashtable<String, List<Object>> subTree = new Hashtable<String, List<Object>>();
            subTree.put(question, new ArrayList<Object>());

            // Recursive function to build inner tree for Data Below and Data Above.
            Object yesAnswer = buildDecisionTree(dataBelow, columnHeaders);
            Object noAnswer = buildDecisionTree(dataAbove, columnHeaders);

            // Add answers to the question.
            ((ArrayList<Object>) subTree.get(question)).add(yesAnswer);
            ((ArrayList<Object>) subTree.get(question)).add(noAnswer);

            return subTree;
        }
    }



    /** Function is a recursive function which returns an object of yes answer or no answer.
    Finally returns a Yes answer (Label of Class).
 */
    public static Object classifyExample(Data exampleData, List<String> columnHeaders, Hashtable<String, List<Object>> tree) {
        
        // Get the first question from Decision Tree: Hashtable<String, List<Object>>
        Enumeration<String> keys = tree.keys();
        String question = keys.nextElement();
    
    
        // Split the question into feature name and it's value for comparison.
        String featureName = question.split(" ")[0];
        String value = question.split(" ")[2];
    
    
        // Initialize answer object.
        Object answer = new Object();
        
    
        // Ask question to test data. (Comapre the feature value)
        if (exampleData.getColumn(columnHeaders.indexOf(featureName)).get(0).equals(value)) {
            answer = tree.get(question).get(0);
        } else {
            answer = tree.get(question).get(1);
        }
        
    
        // Chek if answer is yes answer.
        // If not then repeat the process with no answer.
        if (answer instanceof String) {
            return answer;
        } else {
            @SuppressWarnings("unchecked")
            Hashtable<String, List<Object>> residualTree = (Hashtable<String, List<Object>>) answer;
            return classifyExample(exampleData, columnHeaders, residualTree);
        }
    }
}
