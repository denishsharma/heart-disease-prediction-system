/** KeyValuePair Class stores related value pair.
    K: DataType of Key.
    V: DataType of Value.
 */
public class KeyValuePair<K, V> {
    K key;
    V value;

    public KeyValuePair() {}
    public KeyValuePair(K key, V value) {
        this.key = key;
        this.value = value;
    }
}