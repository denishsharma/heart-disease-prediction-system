import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/** Data class to store dataset that will be loaded from CSV file.
 */
public class Data {
    List<DataValue> rows = new ArrayList<DataValue>();


    public Data() {}
    public Data(List<DataValue> rows) {
        this.rows = rows;
    }



    /** Get one row from the data and return as Data class.
     */
    public Data getOne(int index) {
        List<DataValue> row = new ArrayList<DataValue>();
        row.add(rows.get(index));
        return new Data(row);
    }



    /** Get sub data from the data and return as Data class.
     */
    public Data get(int rowCount) {
        return new Data(rows.subList(0, rowCount));
    }
    public Data get(int fromIndex, int rowCount) {
        return new Data(rows.subList(fromIndex, rowCount));
    }
    


    /** Get all the values from the column and return as List of String.
     */
    public List<String> getColumn(int columnIndex) {
        List<String> tempColumn = new ArrayList<String>();

        for (int i=0; i < rows.size(); i++) {
            tempColumn.add(rows.get(i).values.get(columnIndex));
        }

        return tempColumn;
    }



    /** Convert Data class to 2D List of String to print it for verification.
     */
    public List<List<String>> toList() {
        List<List<String>> tempList = new ArrayList<List<String>>();

        for (DataValue row: rows) {
            tempList.add(row.values);
        }
        
        return tempList;
    }



    /** Get length of the data. (Size of rows)
     */
    public Integer getLength() {
        return rows.size();
    }



    /** Get all the unique values from the column and return as List of String.
     */
    public List<String> getUniqueValues(int columnIndex) {
        String[] uniqueValues = this.getColumn(columnIndex).stream().distinct().toArray(String[]::new);
        return Arrays.asList(uniqueValues);
    }



    /** Get shape of the data. (Rows x Columns)
     */
    public List<Integer> getShape() {
        List<Integer> tempShape = new ArrayList<Integer>();
        tempShape.add(rows.size());
        if (rows.size() > 0) {
            tempShape.add(rows.get(0).values.size());
        } else { tempShape.add(0); }
        return tempShape;
    }
}