import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Helpers {
    
    
    /** Get unique all values from List of String.
     */
    public static List<String> getUniqueValues(List<String> values) {
        String[] uniqueValues = values.stream().distinct().toArray(String[]::new);
        return Arrays.asList(uniqueValues);
    }



    /** Get frequency of all unique values from List of String. i.e. number of occurance of unique values in the list.
        Returns KeyValuePair<String, Integer>
        String: Unique value.
        Integer: Count of unique value.
     */
    public static List<KeyValuePair<String, Integer>> getFrequency(List<String> uniqueValues, List<String> list) {
        List<KeyValuePair<String, Integer>> tempList = new ArrayList<KeyValuePair<String, Integer>>();

        for (String s: uniqueValues) {
            tempList.add(new KeyValuePair<String, Integer>(s, Collections.frequency(list, s)));
        }

        return tempList;
    }



    /** Get index of maximum frequency from frequency list.
     */
    public static Integer getIndexOfMaxFrequency(List<Integer> frequencyList) {
        Integer max = frequencyList.get(0);
        for (Integer x: frequencyList) {
            if (x > max) { max = x; }
        }         
        return frequencyList.indexOf(max);
    }



    /** Read data from CSV file and build Data class from it and returns List of Object.
        Return Object 1: Row Count
        Return Object 2: Column Count
        Return Object 3: Data Class
        Return Object 4: Column Header (List of Column Name)
     */
    public static List<Object> readData(String filePath) {
        String line = "";
        String delimiter = ",";

        Integer rowCount = 0;
        Integer columnCount = 0;
        Data tempData = new Data();
        List<String> columnHeaders = new ArrayList<String>();

        List<Object> tempList = new ArrayList<Object>();

        try {
            BufferedReader br = new BufferedReader(new FileReader(filePath));

            List<DataValue> tempDataValues = new ArrayList<DataValue>();

            while ((line = br.readLine()) != null) {
                String[] rowValues = line.split(delimiter);

                if (rowCount == 0) {
                    for (int i=0; i < rowValues.length; i++) {
                        columnHeaders.add(rowValues[i]);
                        columnCount++;
                    }

                } else {
                    List<String> tempDataValue = new ArrayList<String>();

                    for (int i=0; i < rowValues.length; i++) {
                        tempDataValue.add(rowValues[i]);
                    }

                    tempDataValues.add(new DataValue(tempDataValue));
                }

                rowCount++;
            }

            br.close();

            tempData = new Data(tempDataValues);

            tempList.add(rowCount);
            tempList.add(columnCount);
            tempList.add(tempData);
            tempList.add(columnHeaders);
        } catch (Exception e) { e.printStackTrace(); }

        return tempList;
    }
}
