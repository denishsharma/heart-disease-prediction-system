import java.util.ArrayList;
import java.util.List;


/** DataValue class to store value of columns.
    One DataValue class represent the column values for one row.
 */
public class DataValue {
    List<String> values = new ArrayList<String>();


    public DataValue() {}
    public DataValue(List<String> values) {
        this.values = values;
    }
}