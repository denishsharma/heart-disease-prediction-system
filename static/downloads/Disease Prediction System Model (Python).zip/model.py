import numpy as np
import pandas as pd

from sklearn import preprocessing
from sklearn.tree import DecisionTreeClassifier
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import mean_absolute_error, f1_score

train_df = pd.read_csv('train.csv')

cols = train_df.columns
cols = cols[:-1]

x = train_df.iloc[:, :-1]
y = train_df['disease']

le = preprocessing.LabelEncoder()
le.fit(y)
y = le.transform(y)

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.33, random_state=42)

clf = DecisionTreeClassifier()
clf.fit(x_train, y_train)

scores = cross_val_score(clf, x_test, y_test, cv=10)
print("Score: ", scores.mean())